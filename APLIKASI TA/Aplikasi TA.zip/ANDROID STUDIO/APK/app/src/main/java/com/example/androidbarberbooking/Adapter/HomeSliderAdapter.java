package com.example.androidbarberbooking.Adapter;

import com.example.androidbarberbooking.Model.Banner;

import java.util.List;

import ss.com.bannerslider.adapters.SliderAdapter;
import ss.com.bannerslider.viewholder.ImageSlideViewHolder;

public class HomeSliderAdapter extends SliderAdapter {

    List<Banner> bannerList;

    public HomeSliderAdapter(List<Banner> banners) {
    }

    @Override
    public int getItemCount() {
        return bannerList.size();
    }

    @Override
    public void onBindImageSlide(int position, ImageSlideViewHolder imageSlideViewHolder) {
        imageSlideViewHolder.bindImageSlider(bannerList.get(position).getImage());
    }
}
