package com.example.androidbarberbooking.Common;

import com.example.androidbarberbooking.Model.User;

public class Common {
    public static String IS_LOGIN = "IsLogin";
    public static User currentUser;
}
