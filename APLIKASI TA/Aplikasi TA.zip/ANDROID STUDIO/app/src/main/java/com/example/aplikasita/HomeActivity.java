package com.example.aplikasita;

import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private Button buttonNormalCut;
    private Button buttonPremiumCut;
    private Button buttonHairColoring;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Inisialisasi tombol UI
        buttonNormalCut = findViewById(R.id.buttonNormalCut);
        buttonPremiumCut = findViewById(R.id.buttonPremiumCut);
        buttonHairColoring = findViewById(R.id.buttonHairColoring);

        // Mengatur tindakan saat tombol "Booking" di Normal Cut diklik
        buttonNormalCut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke halaman pemesanan dengan mengirim data layanan yang dipilih (Normal Cut)
                Intent intent = new Intent(HomeActivity.this, BookingActivity.class);
                intent.putExtra("service", "Normal Cut");
                startActivity(intent);
            }
        });

        // Mengatur tindakan saat tombol "Booking" di Premium Cut diklik
        buttonPremiumCut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke halaman pemesanan dengan mengirim data layanan yang dipilih (Premium Cut)
                Intent intent = new Intent(HomeActivity.this, BookingActivity.class);
                intent.putExtra("service", "Premium Cut");
                startActivity(intent);
            }
        });

        // Mengatur tindakan saat tombol "Booking" di Hair Coloring diklik
        buttonHairColoring.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke halaman pemesanan dengan mengirim data layanan yang dipilih (Hair Coloring)
                Intent intent = new Intent(HomeActivity.this, BookingActivity.class);
                intent.putExtra("service", "Hair Coloring");
                startActivity(intent);
            }
        });
    }
}
