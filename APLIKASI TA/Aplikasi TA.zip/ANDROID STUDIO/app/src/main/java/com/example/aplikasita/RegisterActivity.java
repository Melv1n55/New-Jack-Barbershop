package com.example.aplikasita;

import android.view.View;
import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private Button buttonRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inisialisasi komponen UI
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonRegister = findViewById(R.id.buttonRegister);

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mendapatkan data yang dimasukkan pengguna
                String username = editTextUsername.getText().toString();
                String email = editTextEmail.getText().toString();
                String password = editTextPassword.getText().toString();

                // Lakukan validasi data (misalnya, pastikan email valid)
                if (isValidData(username, email, password)) {
                    // Lakukan registrasi pengguna di sini, misalnya, dengan mengirim data ke server atau menyimpan di database lokal
                    // Setelah registrasi berhasil, Anda bisa pindah ke halaman berikutnya
                }
            }
        });
    }

    private boolean isValidData(String username, String email, String password) {
        // Tambahkan logika validasi data di sini, misalnya, cek email valid, password cukup kuat, dsb.
        return true; // Kembalikan true jika data valid, false jika tidak
    }
}
