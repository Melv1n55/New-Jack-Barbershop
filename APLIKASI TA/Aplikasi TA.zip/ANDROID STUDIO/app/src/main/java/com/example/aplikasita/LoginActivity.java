package com.example.aplikasita;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private TextView textViewRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inisialisasi komponen UI
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        textViewRegister = findViewById(R.id.textViewRegister);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mendapatkan data yang dimasukkan pengguna
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                // Lakukan validasi data (misalnya, cek username dan password)
                if (isValidData(username, password)) {
                    // Jika data valid, Anda bisa melakukan proses login di sini
                    // Misalnya, periksa kecocokan username dan password dengan data yang tersimpan
                }
            }
        });

        // Menangani klik pada TextView "Don't have an account? Register"
        textViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke halaman registrasi (gantilah "RegisterActivity" dengan nama aktivitas registrasi Anda)
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean isValidData(String username, String password) {
        // Tambahkan logika validasi data di sini, misalnya, cek apakah username dan password valid
        return true; // Kembalikan true jika data valid, false jika tidak
    }
}
