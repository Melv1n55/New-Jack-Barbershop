package com.example.barbershop;

import android.os.Bundle;

public class AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
    }
}
